
public class JFIncluiOrcamento extends javax.swing.JFrame {

   
    private java.util.List<model.Obra> listaObras;
private java.util.List<model.Fase> listaFases;

public JFIncluiOrcamento() {
    initComponents();
    setLocationRelativeTo(null);
    dao.TelaHelper.configurarMenu(this, PaginaInicial, Obras, FasesObra, Engenheiro, Funcao, Orcamento, Sair);
    bntSalvar.setText("Salvar Orçamento");
    carregarCombos();
    bntSalvar.addActionListener(e -> salvarOrcamento());
    bntCancelar.addActionListener(e -> dao.TelaHelper.abrirTela(this, "JFOrçamento"));
}

private void carregarCombos() {
    try {
        listaObras = new dao.ObraDAO().listarTodos();
        CBObra.removeAllItems();
        for (model.Obra o : listaObras) {
            CBObra.addItem(o.getIdObra() + " - " + o.getDescricao());
        }
        listaFases = new dao.FaseDAO().listarTodos();
        CBFase.removeAllItems();
        CBFase.addItem("Nenhuma");
        for (model.Fase f : listaFases) {
            CBFase.addItem(f.getIdFase() + " - " + f.getDsFase());
        }
    } catch (Exception ex) {
        dao.TelaHelper.erro(this, "Erro ao carregar dados:", ex);
    }
}

private void salvarOrcamento() {
    try {
        int idxObra = CBObra.getSelectedIndex();
        if (listaObras == null || idxObra < 0) {
            dao.TelaHelper.aviso(this, "Selecione uma obra.");
            return;
        }
        model.Obra obra = listaObras.get(idxObra);
        java.time.LocalDate dataOrc = dao.TelaHelper.parseData(dtOrcamento.getText());
        java.math.BigDecimal valorOrcado = new java.math.BigDecimal(valor.getText().trim().replace(",", "."));
        model.Orcamento orc = new model.Orcamento();
        orc.setDtAprovacao(dataOrc);
        orc.setEngenheiroResponsavel(obra.getEngenheiroResponsavel());
        int idOrc = new dao.OrcamentoDAO().inserirRetornandoId(orc);
        orc.setIdOrcamento(idOrc);

        model.ObraOrcamento oo = new model.ObraOrcamento();
        oo.setOrcamento(orc);
        oo.setObra(obra);
        oo.setDtInicio(dataOrc);
        oo.setDtFim(obra.getDtFim());
        oo.setVlPrevisto(valorOrcado);
        oo.setVlRealizado(java.math.BigDecimal.ZERO);

        new dao.ObraOrcamentoDAO().inserir(oo);
        dao.TelaHelper.aviso(this, "Orçamento cadastrado com sucesso!");
        dao.TelaHelper.abrirTela(this, "JFOrçamento");
    } catch (Exception ex) {
        dao.TelaHelper.erro(this, "Erro ao salvar orçamento (data dd/MM/aaaa e valor numérico):", ex);
    }
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bntSalvar = new javax.swing.JButton();
        bntCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        dtOrcamento = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CBObra = new javax.swing.JComboBox<>();
        CBFase = new javax.swing.JComboBox<>();
        valor = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        dsOrcamento = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        PaginaInicial = new javax.swing.JMenu();
        Obras = new javax.swing.JMenu();
        FasesObra = new javax.swing.JMenu();
        Engenheiro = new javax.swing.JMenu();
        Funcao = new javax.swing.JMenu();
        Orcamento = new javax.swing.JMenu();
        Sair = new javax.swing.JMenu();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Incluir Orçamento");

        bntSalvar.setBackground(new java.awt.Color(51, 102, 255));
        bntSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bntSalvar.setText("Salvar Orçamento");
        bntSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));

        bntCancelar.setBackground(new java.awt.Color(242, 242, 242));
        bntCancelar.setText("Cancelar ");
        bntCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Preencha os dados do orçamento para efetuar a inclusão no sistema.");

        jLabel3.setText("Obra");

        jLabel4.setText("Fase da Obra (Opcional)");

        jLabel5.setText("Data do Orçamento");

        jLabel6.setText("Valor Orçado (R$)");

        CBObra.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        CBFase.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setText("Descrição / Observações (Opcional) ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(valor, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CBFase, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CBObra, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dtOrcamento, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dsOrcamento))
                        .addGap(24, 24, 24))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 29, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CBObra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CBFase, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dtOrcamento, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(valor, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dsOrcamento)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        PaginaInicial.setText("Página Inicial");
        jMenuBar1.add(PaginaInicial);

        Obras.setText("Obras");
        jMenuBar1.add(Obras);

        FasesObra.setText("Fases da obra");
        jMenuBar1.add(FasesObra);

        Engenheiro.setText("Engenheiros");
        jMenuBar1.add(Engenheiro);

        Funcao.setText("Funções");
        jMenuBar1.add(Funcao);

        Orcamento.setText("Orçamentos");
        jMenuBar1.add(Orcamento);

        Sair.setText("Sair");
        jMenuBar1.add(Sair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bntCancelarActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFIncluiOrcamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBFase;
    private javax.swing.JComboBox<String> CBObra;
    private javax.swing.JMenu Engenheiro;
    private javax.swing.JMenu FasesObra;
    private javax.swing.JMenu Funcao;
    private javax.swing.JMenu Obras;
    private javax.swing.JMenu Orcamento;
    private javax.swing.JMenu PaginaInicial;
    private javax.swing.JMenu Sair;
    private javax.swing.JButton bntCancelar;
    private javax.swing.JButton bntSalvar;
    private javax.swing.JTextField dsOrcamento;
    private javax.swing.JTextField dtOrcamento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField valor;
    // End of variables declaration//GEN-END:variables
}
