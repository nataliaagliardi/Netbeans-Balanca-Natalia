public class JFIncluiObra extends javax.swing.JFrame {

    private java.util.List<model.Engenheiro> listaEngenheiros;
    private java.util.List<model.Fase> listaFases;

    public JFIncluiObra() {
        initComponents();
        setLocationRelativeTo(null);
        dao.TelaHelper.configurarMenu(this, PaginaInicial, Obras, FasesObra, Engenheiro, Funcao, Orcamento, Sair);
        carregarEngenheiros();
        carregarFases();
        bntSalvar.addActionListener(e -> salvarObra());
        bntCancelar.addActionListener(e -> dao.TelaHelper.abrirTela(this, "JFObras"));
    }

    private void carregarEngenheiros() {
        try {
            listaEngenheiros = new dao.EngenheiroDAO().listarTodos();
            CBEngenheiro.removeAllItems();
            for (model.Engenheiro eng : listaEngenheiros) {
                CBEngenheiro.addItem(eng.getIdEngenheiro() + " - " + eng.getDsNome() + " (CREA: " + eng.getNrCREA() + ")");
            }
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao carregar engenheiros:", ex);
        }
    }

    private void carregarFases() {
        try {
            listaFases = new dao.FaseDAO().listarTodos();
            CBFase.removeAllItems();
            CBFase.addItem("Nenhuma");
            for (model.Fase f : listaFases) {
                CBFase.addItem(f.getIdFase() + " - " + f.getDsFase());
            }
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao carregar fases:", ex);
        }
    }

    private void salvarObra() {
        try {
            int idx = CBEngenheiro.getSelectedIndex();
            if (listaEngenheiros == null || idx < 0) {
                dao.TelaHelper.aviso(this, "Selecione um engenheiro responsável.");
                return;
            }
            String desc = dsObra.getText().trim();
            if (desc.isEmpty()) {
                dao.TelaHelper.aviso(this, "Informe a descrição da obra.");
                return;
            }
            java.time.LocalDate dataIni = dao.TelaHelper.parseData(dtInicio.getText());
            if (dataIni == null) {
                dao.TelaHelper.aviso(this, "Informe a data de início da obra (dd/MM/aaaa).");
                return;
            }
            java.time.LocalDate dataFim = dao.TelaHelper.parseData(dtTermino.getText());

            model.Engenheiro eng = listaEngenheiros.get(idx);
            model.Obra obra = new model.Obra();
            obra.setDescricao(desc);
            obra.setDtInicio(dataIni);
            obra.setDtFim(dataFim);
            obra.setEngenheiroResponsavel(eng);
            obra.setNrCrea(eng.getNrCREA());
            obra.setDtAdmissaoEngenheiro(eng.getDtAdmissao());

            int idObraGerado = new dao.ObraDAO().inserirRetornandoId(obra);
            obra.setIdObra(idObraGerado);

            int idxFase = CBFase.getSelectedIndex();
            if (listaFases != null && idxFase > 0 && idObraGerado > 0) {
                model.Fase faseSelecionada = listaFases.get(idxFase - 1);
                model.ObraFase obraFase = new model.ObraFase();
                obraFase.setObra(obra);
                obraFase.setFase(faseSelecionada);
                obraFase.setDtInicioFase(dataIni);
                obraFase.setDtTerminoFase(dataFim);
                new dao.ObraFaseDAO().inserir(obraFase);
            }

            dao.TelaHelper.aviso(this, "Obra cadastrada com sucesso!");
            dao.TelaHelper.abrirTela(this, "JFObras");
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao salvar obra (use datas dd/MM/aaaa):", ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bntSalvar = new javax.swing.JButton();
        bntCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        dsObra = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dtInicio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dtTermino = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CBEngenheiro = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        CBFase = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        PaginaInicial = new javax.swing.JMenu();
        Obras = new javax.swing.JMenu();
        FasesObra = new javax.swing.JMenu();
        Engenheiro = new javax.swing.JMenu();
        Funcao = new javax.swing.JMenu();
        Orcamento = new javax.swing.JMenu();
        Sair = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Incluir Obra");

        bntSalvar.setBackground(new java.awt.Color(51, 102, 255));
        bntSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bntSalvar.setText("Salvar Obra");
        bntSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));

        bntCancelar.setBackground(new java.awt.Color(242, 242, 242));
        bntCancelar.setText("Cancelar ");
        bntCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Preencha os dados da obra para efetuar a inclusão no sistema.");

        jLabel3.setText("Descrição / Nome da Obra");

        jLabel4.setText("Data de Início");

        jLabel5.setText("Data de Término (Prevista/Real)");

        jLabel6.setText("Engenheiro Responsável Técnico");

        CBEngenheiro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setText("Fase da obra");

        CBFase.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 29, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(CBFase, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CBEngenheiro, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dtTermino, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dtInicio, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dsObra, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(24, 24, 24))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dsObra, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dtInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dtTermino, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CBEngenheiro, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CBFase, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        jMenuBar1.setMaximumSize(new java.awt.Dimension(630, 42768));

        PaginaInicial.setText("Página Inicial");
        jMenuBar1.add(PaginaInicial);

        Obras.setText("Obras");
        jMenuBar1.add(Obras);

        FasesObra.setText("Fases da obra");
        jMenuBar1.add(FasesObra);

        Engenheiro.setText("Engenheiros");
        jMenuBar1.add(Engenheiro);

        Funcao.setText("Funções");
        jMenuBar1.add(Funcao);

        Orcamento.setText("Orçamentos");
        jMenuBar1.add(Orcamento);

        Sair.setText("Sair");
        jMenuBar1.add(Sair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(118, 118, 118))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bntCancelarActionPerformed

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFIncluiObra().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBEngenheiro;
    private javax.swing.JComboBox<String> CBFase;
    private javax.swing.JMenu Engenheiro;
    private javax.swing.JMenu FasesObra;
    private javax.swing.JMenu Funcao;
    private javax.swing.JMenu Obras;
    private javax.swing.JMenu Orcamento;
    private javax.swing.JMenu PaginaInicial;
    private javax.swing.JMenu Sair;
    private javax.swing.JButton bntCancelar;
    private javax.swing.JButton bntSalvar;
    private javax.swing.JTextField dsObra;
    private javax.swing.JTextField dtInicio;
    private javax.swing.JTextField dtTermino;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
