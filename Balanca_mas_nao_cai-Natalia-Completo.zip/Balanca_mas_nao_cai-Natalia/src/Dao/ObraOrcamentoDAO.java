package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import model.Obra;
import model.ObraOrcamento;
import model.Orcamento;

public class ObraOrcamentoDAO {

    public void inserir(ObraOrcamento oo) throws SQLException {
        String sql = "INSERT INTO orcamentos_obras (idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, oo.getOrcamento().getIdOrcamento());
            stmt.setInt(2, oo.getObra().getIdObra());
            if (oo.getDtInicio() != null) {
                stmt.setDate(3, Date.valueOf(oo.getDtInicio()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            if (oo.getDtFim() != null) {
                stmt.setDate(4, Date.valueOf(oo.getDtFim()));
            } else {
                stmt.setNull(4, Types.DATE);
            }
            stmt.setBigDecimal(5, oo.getVlPrevisto());
            stmt.setBigDecimal(6, oo.getVlRealizado());
            stmt.executeUpdate();
        }
    }

    public void alterar(ObraOrcamento oo) throws SQLException {
        String sql = "UPDATE orcamentos_obras SET dtInicio = ?, dtFim = ?, vlPrevisto = ?, vlRealizado = ? "
                   + "WHERE idOrcamento = ? AND idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (oo.getDtInicio() != null) {
                stmt.setDate(1, Date.valueOf(oo.getDtInicio()));
            } else {
                stmt.setNull(1, Types.DATE);
            }
            if (oo.getDtFim() != null) {
                stmt.setDate(2, Date.valueOf(oo.getDtFim()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            stmt.setBigDecimal(3, oo.getVlPrevisto());
            stmt.setBigDecimal(4, oo.getVlRealizado());
            stmt.setInt(5, oo.getOrcamento().getIdOrcamento());
            stmt.setInt(6, oo.getObra().getIdObra());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idOrcamento, int idObra) throws SQLException {
        String sql = "DELETE FROM orcamentos_obras WHERE idOrcamento = ? AND idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idOrcamento);
            stmt.setInt(2, idObra);
            stmt.executeUpdate();
        }
    }

    public List<ObraOrcamento> listarTodos() throws SQLException {
    List<ObraOrcamento> lista = new ArrayList<>();
    String sql = "SELECT oo.*, o.Descricao, orc.dtAprovacao "
               + "FROM orcamentos_obras oo "
               + "INNER JOIN obras o ON oo.idObra = o.idObra "
               + "INNER JOIN orcamentos orc ON oo.idOrcamento = orc.idOrcamento "
               + "ORDER BY oo.idOrcamento, oo.idObra";
    try (Connection conn = Conexao.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            Orcamento orc = new Orcamento();
            orc.setIdOrcamento(rs.getInt("idOrcamento"));
            Date dtAprov = rs.getDate("dtAprovacao");
            if (dtAprov != null) orc.setDtAprovacao(dtAprov.toLocalDate());

            Obra obra = new Obra();
            obra.setIdObra(rs.getInt("idObra"));
            obra.setDescricao(rs.getString("Descricao"));

            Date ini = rs.getDate("dtInicio");
            Date fim = rs.getDate("dtFim");

            lista.add(new ObraOrcamento(
                orc,
                obra,
                ini != null ? ini.toLocalDate() : null,
                fim != null ? fim.toLocalDate() : null,
                rs.getBigDecimal("vlPrevisto"),
                rs.getBigDecimal("vlRealizado")
            ));
        }
    }
    return lista;
}
}