package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.usuario;

public class UsuarioDAO {

    public usuario autenticar(String email, String senha) throws SQLException {
        String sql = "SELECT idUsuario, Nome, Email, Senha FROM usuarios WHERE Email = ? AND Senha = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, senha);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public void inserir(usuario u) throws SQLException {
        String sql = "INSERT INTO usuarios (Nome, Email, Senha) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getEmail());
            stmt.setString(3, u.getSenha());
            stmt.executeUpdate();
        }
    }

    public void alterar(usuario u) throws SQLException {
        String sql = "UPDATE usuarios SET Nome = ?, Email = ?, Senha = ? WHERE idUsuario = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getEmail());
            stmt.setString(3, u.getSenha());
            stmt.setInt(4, u.getIdUsuario());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idUsuario) throws SQLException {
        String sql = "DELETE FROM usuarios WHERE idUsuario = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            stmt.executeUpdate();
        }
    }

    public List<usuario> listarTodos() throws SQLException {
        List<usuario> lista = new ArrayList<>();
        String sql = "SELECT idUsuario, Nome, Email, Senha FROM usuarios ORDER BY Nome";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private usuario mapear(ResultSet rs) throws SQLException {
        usuario u = new usuario();
        u.setIdUsuario(rs.getInt("idUsuario"));
        u.setNome(rs.getString("Nome"));
        u.setEmail(rs.getString("Email"));
        u.setSenha(rs.getString("Senha"));
        return u;
    }
}