package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import model.Engenheiro;
import model.Orcamento;

public class OrcamentoDAO {

    public void inserir(Orcamento orc) throws SQLException {
        String sql = "INSERT INTO orcamentos (dtAprovacao, idEngenheiroResponsavel) VALUES (?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (orc.getDtAprovacao() != null) {
                stmt.setDate(1, Date.valueOf(orc.getDtAprovacao()));
            } else {
                stmt.setNull(1, Types.DATE);
            }
            stmt.setInt(2, orc.getEngenheiroResponsavel().getIdEngenheiro());
            stmt.executeUpdate();
        }
    }

    public void alterar(Orcamento orc) throws SQLException {
        String sql = "UPDATE orcamentos SET dtAprovacao = ?, idEngenheiroResponsavel = ? WHERE idOrcamento = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (orc.getDtAprovacao() != null) {
                stmt.setDate(1, Date.valueOf(orc.getDtAprovacao()));
            } else {
                stmt.setNull(1, Types.DATE);
            }
            stmt.setInt(2, orc.getEngenheiroResponsavel().getIdEngenheiro());
            stmt.setInt(3, orc.getIdOrcamento());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idOrcamento) throws SQLException {
        String sql = "DELETE FROM orcamentos WHERE idOrcamento = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idOrcamento);
            stmt.executeUpdate();
        }
    }

    public Orcamento buscarPorId(int idOrcamento) throws SQLException {
        String sql = "SELECT orc.*, e.dsNome, e.nrCREA, e.dtAdmissao "
                   + "FROM orcamentos orc INNER JOIN engenheiros e ON orc.idEngenheiroResponsavel = e.idEngenheiro "
                   + "WHERE orc.idOrcamento = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idOrcamento);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Orcamento> listarTodos() throws SQLException {
        List<Orcamento> lista = new ArrayList<>();
        String sql = "SELECT orc.*, e.dsNome, e.nrCREA, e.dtAdmissao "
                   + "FROM orcamentos orc INNER JOIN engenheiros e ON orc.idEngenheiroResponsavel = e.idEngenheiro "
                   + "ORDER BY orc.idOrcamento";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Orcamento mapear(ResultSet rs) throws SQLException {
        Date engAdm = rs.getDate("dtAdmissao");
        Engenheiro eng = new Engenheiro(
            rs.getInt("idEngenheiroResponsavel"),
            rs.getString("dsNome"),
            rs.getString("nrCREA"),
            engAdm != null ? engAdm.toLocalDate() : null
        );
        Date dtAprov = rs.getDate("dtAprovacao");
        return new Orcamento(
            rs.getInt("idOrcamento"),
            dtAprov != null ? dtAprov.toLocalDate() : null,
            eng
        );
    }
    public int inserirRetornandoId(Orcamento orc) throws SQLException {
    String sql = "INSERT INTO orcamentos (dtAprovacao, idEngenheiroResponsavel) VALUES (?, ?)";
    try (Connection conn = Conexao.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
        if (orc.getDtAprovacao() != null) {
            stmt.setDate(1, Date.valueOf(orc.getDtAprovacao()));
        } else {
            stmt.setNull(1, Types.DATE);
        }
        stmt.setInt(2, orc.getEngenheiroResponsavel().getIdEngenheiro());
        stmt.executeUpdate();
        try (ResultSet rs = stmt.getGeneratedKeys()) {
            if (rs.next()) return rs.getInt(1);
        }
    }
    return 0;
}
}