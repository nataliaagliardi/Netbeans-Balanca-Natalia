package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import model.Fase;
import model.Obra;
import model.ObraFase;

public class ObraFaseDAO {

    public void inserir(ObraFase of) throws SQLException {
        String sql = "INSERT INTO obras_fases (idObra, idFase, dtIniciofase, dtTerminoFase) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, of.getObra().getIdObra());
            stmt.setInt(2, of.getFase().getIdFase());
            if (of.getDtInicioFase() != null) {
                stmt.setDate(3, Date.valueOf(of.getDtInicioFase()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            if (of.getDtTerminoFase() != null) {
                stmt.setDate(4, Date.valueOf(of.getDtTerminoFase()));
            } else {
                stmt.setNull(4, Types.DATE);
            }
            stmt.executeUpdate();
        }
    }

    public void alterar(ObraFase of) throws SQLException {
        String sql = "UPDATE obras_fases SET dtIniciofase = ?, dtTerminoFase = ? WHERE idObra = ? AND idFase = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (of.getDtInicioFase() != null) {
                stmt.setDate(1, Date.valueOf(of.getDtInicioFase()));
            } else {
                stmt.setNull(1, Types.DATE);
            }
            if (of.getDtTerminoFase() != null) {
                stmt.setDate(2, Date.valueOf(of.getDtTerminoFase()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            stmt.setInt(3, of.getObra().getIdObra());
            stmt.setInt(4, of.getFase().getIdFase());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idObra, int idFase) throws SQLException {
        String sql = "DELETE FROM obras_fases WHERE idObra = ? AND idFase = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            stmt.setInt(2, idFase);
            stmt.executeUpdate();
        }
    }

    public List<ObraFase> listarPorObra(int idObra) throws SQLException {
        List<ObraFase> lista = new ArrayList<>();
        String sql = "SELECT ofa.*, o.Descricao, f.dsFase "
                   + "FROM obras_fases ofa "
                   + "INNER JOIN obras o ON ofa.idObra = o.idObra "
                   + "INNER JOIN fases f ON ofa.idFase = f.idFase "
                   + "WHERE ofa.idObra = ? ORDER BY ofa.idFase";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Obra obra = new Obra();
                    obra.setIdObra(rs.getInt("idObra"));
                    obra.setDescricao(rs.getString("Descricao"));

                    Fase fase = new Fase(rs.getInt("idFase"), rs.getString("dsFase"));

                    Date ini = rs.getDate("dtIniciofase");
                    Date fim = rs.getDate("dtTerminoFase");

                    lista.add(new ObraFase(
                        obra,
                        fase,
                        ini != null ? ini.toLocalDate() : null,
                        fim != null ? fim.toLocalDate() : null
                    ));
                }
            }
        }
        return lista;
    }
}