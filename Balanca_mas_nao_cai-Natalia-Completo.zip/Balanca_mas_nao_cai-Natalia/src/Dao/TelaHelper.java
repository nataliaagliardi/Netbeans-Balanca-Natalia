package dao;

import java.awt.Component;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class TelaHelper {

    private static final DateTimeFormatter FMT_BR = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static LocalDate parseData(String texto) {
        if (texto == null || texto.trim().isEmpty()) return null;
        String t = texto.trim();
        try {
            return LocalDate.parse(t, FMT_BR);
        } catch (DateTimeParseException e) {
            return LocalDate.parse(t); 
        }
    }

    public static String formatarData(LocalDate data) {
        return data != null ? data.format(FMT_BR) : "";
    }

    public static void erro(Component parent, String msg, Exception ex) {
        ex.printStackTrace();
        Throwable causa = (ex.getCause() != null) ? ex.getCause() : ex;
        JOptionPane.showMessageDialog(parent, msg + "\nMotivo: " + causa.toString(), "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public static void aviso(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Aviso", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void abrirTela(JFrame atual, String nomeClasse) {
        try {
            JFrame nova = (JFrame) Class.forName(nomeClasse).getDeclaredConstructor().newInstance();
            nova.setLocationRelativeTo(null);
            nova.setVisible(true);
            if (atual != null) atual.dispose();
        } catch (Exception e) {
            erro(atual, "Não foi possível abrir a tela " + nomeClasse, e);
        }
    }

    public static void configurarMenu(JFrame atual, JMenu mInicio, JMenu mObras, JMenu mFases,
                                      JMenu mEng, JMenu mFunc, JMenu mOrc, JMenu mSair) {
        aoClicarMenu(mInicio, () -> abrirTela(atual, "JFTela_inicial"));
        aoClicarMenu(mObras, () -> abrirTela(atual, "JFObras"));
        aoClicarMenu(mFases, () -> abrirTela(atual, "JFFasesDaObra"));
        aoClicarMenu(mEng, () -> abrirTela(atual, "JFEngenheiros"));
        aoClicarMenu(mFunc, () -> abrirTela(atual, "JFFuncoes"));
        aoClicarMenu(mOrc, () -> abrirTela(atual, "JFOrçamento"));
        aoClicarMenu(mSair, () -> abrirTela(atual, "login"));
    }

    private static void aoClicarMenu(JMenu menu, Runnable acao) {
        if (menu == null) return;
        menu.removeAll();
        menu.addMenuListener(new MenuListener() {
            @Override public void menuSelected(MenuEvent e) { acao.run(); }
            @Override public void menuDeselected(MenuEvent e) {}
            @Override public void menuCanceled(MenuEvent e) {}
        });
    }
}