package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private static final String HOSTNAME = "192.168.20.5";
    private static final int PORTA = 3306;
    private static final String DATABASE = "balanca_mas_nao_cai";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "12345";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL não encontrado: " + e.getMessage(), e);
        }
        String url = "jdbc:mysql://" + HOSTNAME + ":" + PORTA + "/" + DATABASE
                   + "?useTimezone=true&serverTimezone=UTC";
        return DriverManager.getConnection(url, USERNAME, PASSWORD);
    }
}