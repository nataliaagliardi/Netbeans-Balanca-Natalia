package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Fase;

public class FaseDAO {

    public void inserir(Fase fase) throws SQLException {
        String sql = "INSERT INTO fases (dsFase) VALUES (?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fase.getDsFase());
            stmt.executeUpdate();
        }
    }

    public void alterar(Fase fase) throws SQLException {
        String sql = "UPDATE fases SET dsFase = ? WHERE idFase = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fase.getDsFase());
            stmt.setInt(2, fase.getIdFase());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idFase) throws SQLException {
        String sql = "DELETE FROM fases WHERE idFase = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idFase);
            stmt.executeUpdate();
        }
    }

    public Fase buscarPorId(int idFase) throws SQLException {
        String sql = "SELECT idFase, dsFase FROM fases WHERE idFase = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idFase);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Fase(rs.getInt("idFase"), rs.getString("dsFase"));
                }
            }
        }
        return null;
    }

    public List<Fase> listarTodos() throws SQLException {
        List<Fase> lista = new ArrayList<>();
        String sql = "SELECT idFase, dsFase FROM fases ORDER BY idFase";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new Fase(rs.getInt("idFase"), rs.getString("dsFase")));
            }
        }
        return lista;
    }
}