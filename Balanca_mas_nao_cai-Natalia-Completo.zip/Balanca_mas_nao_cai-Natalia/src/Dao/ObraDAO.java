package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import model.Engenheiro;
import model.Obra;

public class ObraDAO {

    public void inserir(Obra obra) throws SQLException {
        inserirRetornandoId(obra);
    }

    public int inserirRetornandoId(Obra obra) throws SQLException {
        String sql = "INSERT INTO obras (Descricao, dtInicio, dtFim, idEngenheiro, nrCrea, dtDdmissaoEngenheiro) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, obra.getDescricao());
            stmt.setDate(2, Date.valueOf(obra.getDtInicio()));
            if (obra.getDtFim() != null) {
                stmt.setDate(3, Date.valueOf(obra.getDtFim()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            stmt.setInt(4, obra.getEngenheiroResponsavel().getIdEngenheiro());
            stmt.setString(5, obra.getNrCrea());
            stmt.setDate(6, Date.valueOf(obra.getDtAdmissaoEngenheiro()));
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    public void alterar(Obra obra) throws SQLException {
        String sql = "UPDATE obras SET Descricao = ?, dtInicio = ?, dtFim = ?, idEngenheiro = ?, "
                   + "nrCrea = ?, dtDdmissaoEngenheiro = ? WHERE idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, obra.getDescricao());
            stmt.setDate(2, Date.valueOf(obra.getDtInicio()));
            if (obra.getDtFim() != null) {
                stmt.setDate(3, Date.valueOf(obra.getDtFim()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            stmt.setInt(4, obra.getEngenheiroResponsavel().getIdEngenheiro());
            stmt.setString(5, obra.getNrCrea());
            stmt.setDate(6, Date.valueOf(obra.getDtAdmissaoEngenheiro()));
            stmt.setInt(7, obra.getIdObra());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idObra) throws SQLException {
        String sql = "DELETE FROM obras WHERE idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            stmt.executeUpdate();
        }
    }

    public Obra buscarPorId(int idObra) throws SQLException {
        String sql = "SELECT o.*, e.dsNome, e.nrCREA AS engCrea, e.dtAdmissao AS engDtAdmissao "
                   + "FROM obras o INNER JOIN engenheiros e ON o.idEngenheiro = e.idEngenheiro "
                   + "WHERE o.idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Obra> listarTodos() throws SQLException {
        List<Obra> lista = new ArrayList<>();
        String sql = "SELECT o.*, e.dsNome, e.nrCREA AS engCrea, e.dtAdmissao AS engDtAdmissao "
                   + "FROM obras o INNER JOIN engenheiros e ON o.idEngenheiro = e.idEngenheiro "
                   + "ORDER BY o.idObra";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Obra mapear(ResultSet rs) throws SQLException {
        Date engAdm = rs.getDate("engDtAdmissao");
        Engenheiro eng = new Engenheiro(
            rs.getInt("idEngenheiro"),
            rs.getString("dsNome"),
            rs.getString("engCrea"),
            engAdm != null ? engAdm.toLocalDate() : null
        );

        Date dtInicio = rs.getDate("dtInicio");
        Date dtFim = rs.getDate("dtFim");
        Date dtAdmObra = rs.getDate("dtDdmissaoEngenheiro");

        return new Obra(
            rs.getInt("idObra"),
            rs.getString("Descricao"),
            dtInicio != null ? dtInicio.toLocalDate() : null,
            dtFim != null ? dtFim.toLocalDate() : null,
            eng,
            rs.getString("nrCrea"),
            dtAdmObra != null ? dtAdmObra.toLocalDate() : null
        );
    }
}