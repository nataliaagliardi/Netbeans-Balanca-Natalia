package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Engenheiro;

public class EngenheiroDAO {

    public void inserir(Engenheiro eng) throws SQLException {
        String sql = "INSERT INTO engenheiros (dsNome, nrCREA, dtAdmissao) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, eng.getDsNome());
            stmt.setString(2, eng.getNrCREA());
            stmt.setDate(3, Date.valueOf(eng.getDtAdmissao()));
            stmt.executeUpdate();
        }
    }

    public void alterar(Engenheiro eng) throws SQLException {
        String sql = "UPDATE engenheiros SET dsNome = ?, nrCREA = ?, dtAdmissao = ? WHERE idEngenheiro = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, eng.getDsNome());
            stmt.setString(2, eng.getNrCREA());
            stmt.setDate(3, Date.valueOf(eng.getDtAdmissao()));
            stmt.setInt(4, eng.getIdEngenheiro());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idEngenheiro) throws SQLException {
        String sql = "DELETE FROM engenheiros WHERE idEngenheiro = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEngenheiro);
            stmt.executeUpdate();
        }
    }

    public Engenheiro buscarPorId(int idEngenheiro) throws SQLException {
        String sql = "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao FROM engenheiros WHERE idEngenheiro = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEngenheiro);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Engenheiro> listarTodos() throws SQLException {
        List<Engenheiro> lista = new ArrayList<>();
        String sql = "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao FROM engenheiros ORDER BY dsNome";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public Engenheiro mapear(ResultSet rs) throws SQLException {
        Date dtAdm = rs.getDate("dtAdmissao");
        return new Engenheiro(
            rs.getInt("idEngenheiro"),
            rs.getString("dsNome"),
            rs.getString("nrCREA"),
            dtAdm != null ? dtAdm.toLocalDate() : null
        );
    }
}