package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Engenheiro;
import model.Funcao;
import model.Obra;
import model.ObraEngenheiro;

public class ObraEngenheiroDAO {

    public void inserir(ObraEngenheiro oe) throws SQLException {
        String sql = "INSERT INTO obras_engenheiros (idObra, idEngenheiro, dtAdmissaoEngenheiro, dtInicioTrabalho, dtFimTrabalho, idFuncao) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, oe.getObra().getIdObra());
            stmt.setInt(2, oe.getEngenheiro().getIdEngenheiro());
            stmt.setDate(3, Date.valueOf(oe.getDtAdmissaoEngenheiro()));
            stmt.setDate(4, Date.valueOf(oe.getDtInicioTrabalho()));
            stmt.setDate(5, Date.valueOf(oe.getDtFimTrabalho()));
            stmt.setInt(6, oe.getFuncao().getIdFuncao());
            stmt.executeUpdate();
        }
    }

    public void alterar(ObraEngenheiro oe) throws SQLException {
        String sql = "UPDATE obras_engenheiros SET dtAdmissaoEngenheiro = ?, dtInicioTrabalho = ?, dtFimTrabalho = ?, idFuncao = ? "
                   + "WHERE idObra = ? AND idEngenheiro = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(oe.getDtAdmissaoEngenheiro()));
            stmt.setDate(2, Date.valueOf(oe.getDtInicioTrabalho()));
            stmt.setDate(3, Date.valueOf(oe.getDtFimTrabalho()));
            stmt.setInt(4, oe.getFuncao().getIdFuncao());
            stmt.setInt(5, oe.getObra().getIdObra());
            stmt.setInt(6, oe.getEngenheiro().getIdEngenheiro());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idObra, int idEngenheiro) throws SQLException {
        String sql = "DELETE FROM obras_engenheiros WHERE idObra = ? AND idEngenheiro = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            stmt.setInt(2, idEngenheiro);
            stmt.executeUpdate();
        }
    }

    public List<ObraEngenheiro> listarPorObra(int idObra) throws SQLException {
        List<ObraEngenheiro> lista = new ArrayList<>();
        String sql = "SELECT oe.*, o.Descricao, e.dsNome, e.nrCREA, e.dtAdmissao, f.dsFuncao "
                   + "FROM obras_engenheiros oe "
                   + "INNER JOIN obras o ON oe.idObra = o.idObra "
                   + "INNER JOIN engenheiros e ON oe.idEngenheiro = e.idEngenheiro "
                   + "INNER JOIN funcoes f ON oe.idFuncao = f.idFuncao "
                   + "WHERE oe.idObra = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idObra);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    private ObraEngenheiro mapear(ResultSet rs) throws SQLException {
        Obra obra = new Obra();
        obra.setIdObra(rs.getInt("idObra"));
        obra.setDescricao(rs.getString("Descricao"));

        Date engAdm = rs.getDate("dtAdmissao");
        Engenheiro eng = new Engenheiro(
            rs.getInt("idEngenheiro"),
            rs.getString("dsNome"),
            rs.getString("nrCREA"),
            engAdm != null ? engAdm.toLocalDate() : null
        );

        Funcao funcao = new Funcao(rs.getInt("idFuncao"), rs.getString("dsFuncao"));

        return new ObraEngenheiro(
            obra,
            eng,
            rs.getDate("dtAdmissaoEngenheiro").toLocalDate(),
            rs.getDate("dtInicioTrabalho").toLocalDate(),
            rs.getDate("dtFimTrabalho").toLocalDate(),
            funcao
        );
    }
}