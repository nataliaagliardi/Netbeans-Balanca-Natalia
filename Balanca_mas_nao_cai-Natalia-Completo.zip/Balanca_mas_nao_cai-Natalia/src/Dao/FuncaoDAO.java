package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Funcao;

public class FuncaoDAO {

    public void inserir(Funcao funcao) throws SQLException {
        String sql = "INSERT INTO funcoes (dsFuncao) VALUES (?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, funcao.getDsFuncao());
            stmt.executeUpdate();
        }
    }

    public void alterar(Funcao funcao) throws SQLException {
        String sql = "UPDATE funcoes SET dsFuncao = ? WHERE idFuncao = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, funcao.getDsFuncao());
            stmt.setInt(2, funcao.getIdFuncao());
            stmt.executeUpdate();
        }
    }

    public void excluir(int idFuncao) throws SQLException {
        String sql = "DELETE FROM funcoes WHERE idFuncao = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idFuncao);
            stmt.executeUpdate();
        }
    }

    public Funcao buscarPorId(int idFuncao) throws SQLException {
        String sql = "SELECT idFuncao, dsFuncao FROM funcoes WHERE idFuncao = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idFuncao);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Funcao(rs.getInt("idFuncao"), rs.getString("dsFuncao"));
                }
            }
        }
        return null;
    }

    public List<Funcao> listarTodos() throws SQLException {
        List<Funcao> lista = new ArrayList<>();
        String sql = "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY dsFuncao";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new Funcao(rs.getInt("idFuncao"), rs.getString("dsFuncao")));
            }
        }
        return lista;
    }
}