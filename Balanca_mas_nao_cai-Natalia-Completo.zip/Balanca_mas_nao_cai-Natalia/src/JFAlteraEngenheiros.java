
public class JFAlteraEngenheiros extends javax.swing.JFrame {

    private java.util.List<model.Engenheiro> listaEngenheiros;
    
    public JFAlteraEngenheiros() {
       initComponents();
        setLocationRelativeTo(null); 
        carregarEngenheiros();       
        dao.TelaHelper.configurarMenu(this, PaginaInicial, Obra, FaseObra, Engenheiro, Funcao, Orcamento, Sair);
        bntSalvar.addActionListener(evt -> salvarAlteracao());
    }

    
    @SuppressWarnings("unchecked")
    private void carregarEngenheiros() {
        try {
            listaEngenheiros = new dao.EngenheiroDAO().listarTodos();
            engenheiro.removeAllItems();
            for (model.Engenheiro eng : listaEngenheiros) {
                engenheiro.addItem(eng.getIdEngenheiro() + " - " + eng.getDsNome());
            }
            preencherCampos();
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao carregar engenheiros:", ex);
        }
    }

    private void preencherCampos() {
        int idx = engenheiro.getSelectedIndex();
        if (listaEngenheiros != null && idx >= 0 && idx < listaEngenheiros.size()) {
            model.Engenheiro selecionado = listaEngenheiros.get(idx);
            Nome.setText(selecionado.getDsNome());
            crea.setText(selecionado.getNrCREA());
            dtAdmissao.setText(dao.TelaHelper.formatarData(selecionado.getDtAdmissao()));
        }
    }

    private void salvarAlteracao() {
        try {
            int idx = engenheiro.getSelectedIndex();
            if (listaEngenheiros == null || idx < 0) {
                dao.TelaHelper.aviso(this, "Selecione um engenheiro para alterar.");
                return;
            }

            model.Engenheiro selecionado = listaEngenheiros.get(idx);
            selecionado.setDsNome(Nome.getText().trim());
            selecionado.setNrCREA(crea.getText().trim());
            selecionado.setDtAdmissao(dao.TelaHelper.parseData(dtAdmissao.getText()));

            new dao.EngenheiroDAO().alterar(selecionado);
            dao.TelaHelper.aviso(this, "Engenheiro alterado com sucesso!");
            dao.TelaHelper.abrirTela(this, "JFEngenheiros");
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao alterar engenheiro (use data dd/MM/aaaa):", ex);
        }}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bntSalvar = new javax.swing.JButton();
        bntCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        engenheiro = new javax.swing.JComboBox<>();
        dtAdmissao = new javax.swing.JTextField();
        Nome = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        crea = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        PaginaInicial = new javax.swing.JMenu();
        Obra = new javax.swing.JMenu();
        FaseObra = new javax.swing.JMenu();
        Engenheiro = new javax.swing.JMenu();
        Funcao = new javax.swing.JMenu();
        Orcamento = new javax.swing.JMenu();
        Sair = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Alterar Engenheiro");

        bntSalvar.setBackground(new java.awt.Color(51, 102, 255));
        bntSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bntSalvar.setText("Salvar Engenheiro");
        bntSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));

        bntCancelar.setBackground(new java.awt.Color(242, 242, 242));
        bntCancelar.setText("Cancelar ");
        bntCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Preencha os dados do engenheiro para efetuar a alteração no sistema.");

        engenheiro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        engenheiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                engenheiroActionPerformed(evt);
            }
        });

        jLabel9.setText("Nome Completo");

        jLabel10.setText("Número do CREA");

        jLabel5.setText("Data de admissão");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(engenheiro, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(53, 53, 53))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 165, Short.MAX_VALUE)
                                .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(dtAdmissao, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(crea, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Nome, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(55, 55, 55))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addContainerGap(185, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(engenheiro, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Nome, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(crea, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dtAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(78, Short.MAX_VALUE))
        );

        jMenuBar1.setMaximumSize(new java.awt.Dimension(630, 42768));

        PaginaInicial.setText("Página Inicial");
        jMenuBar1.add(PaginaInicial);

        Obra.setText("Obras");
        jMenuBar1.add(Obra);

        FaseObra.setText("Fases da obra");
        jMenuBar1.add(FaseObra);

        Engenheiro.setText("Engenheiros");
        jMenuBar1.add(Engenheiro);

        Funcao.setText("Funções");
        jMenuBar1.add(Funcao);

        Orcamento.setText("Orçamentos");
        jMenuBar1.add(Orcamento);

        Sair.setText("Sair");
        jMenuBar1.add(Sair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCancelarActionPerformed
        dao.TelaHelper.abrirTela(this, "JFEngenheiros");
        
    }//GEN-LAST:event_bntCancelarActionPerformed

    private void engenheiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_engenheiroActionPerformed
        preencherCampos();
        
    }//GEN-LAST:event_engenheiroActionPerformed

   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu Engenheiro;
    private javax.swing.JMenu FaseObra;
    private javax.swing.JMenu Funcao;
    private javax.swing.JTextField Nome;
    private javax.swing.JMenu Obra;
    private javax.swing.JMenu Orcamento;
    private javax.swing.JMenu PaginaInicial;
    private javax.swing.JMenu Sair;
    private javax.swing.JButton bntCancelar;
    private javax.swing.JButton bntSalvar;
    private javax.swing.JTextField crea;
    private javax.swing.JTextField dtAdmissao;
    private javax.swing.JComboBox<String> engenheiro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
