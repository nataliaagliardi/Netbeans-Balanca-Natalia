

public class JFAlteraObra extends javax.swing.JFrame {

    private java.util.List<model.Obra> listaObras;
    private java.util.List<model.Engenheiro> listaEngenheiros;

    public JFAlteraObra() {
        initComponents();
        setLocationRelativeTo(null);
        dao.TelaHelper.configurarMenu(this, PaginaInicial, Obra, FaseObra, Engenheiro, Funcao, Orcamento, Sair);
        bntSalvar.setText("Salvar Obra");
        codigo.setEnabled(false);
        carregarDados();
        CBObra.addActionListener(e -> preencherCampos());
        bntSalvar.addActionListener(e -> salvarAlteracao());
        bntCancelar.addActionListener(e -> dao.TelaHelper.abrirTela(this, "JFObras"));
    }

    private void carregarDados() {
        try {
            listaEngenheiros = new dao.EngenheiroDAO().listarTodos();
            CBEngenheiro.removeAllItems();
            for (model.Engenheiro eng : listaEngenheiros) {
                CBEngenheiro.addItem(eng.getIdEngenheiro() + " - " + eng.getDsNome());
            }
            listaObras = new dao.ObraDAO().listarTodos();
            CBObra.removeAllItems();
            for (model.Obra o : listaObras) {
                CBObra.addItem(o.getIdObra() + " - " + o.getDescricao());
            }
            preencherCampos();
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao carregar obras:", ex);
        }
    }

    private void preencherCampos() {
        int idx = CBObra.getSelectedIndex();
        if (listaObras != null && idx >= 0 && idx < listaObras.size()) {
            model.Obra o = listaObras.get(idx);
            codigo.setText(String.valueOf(o.getIdObra()));
            dtInicio.setText(dao.TelaHelper.formatarData(o.getDtInicio()));
            dtTermino.setText(dao.TelaHelper.formatarData(o.getDtFim()));
            if (o.getEngenheiroResponsavel() != null && listaEngenheiros != null) {
                for (int i = 0; i < listaEngenheiros.size(); i++) {
                    if (listaEngenheiros.get(i).getIdEngenheiro() == o.getEngenheiroResponsavel().getIdEngenheiro()) {
                        CBEngenheiro.setSelectedIndex(i);
                        break;
                    }
                }
            }
        }
    }

    private void salvarAlteracao() {
        try {
            int idxObra = CBObra.getSelectedIndex();
            int idxEng = CBEngenheiro.getSelectedIndex();
            if (listaObras == null || idxObra < 0 || listaEngenheiros == null || idxEng < 0) {
                dao.TelaHelper.aviso(this, "Selecione a obra e o engenheiro.");
                return;
            }
            model.Obra o = listaObras.get(idxObra);
            model.Engenheiro eng = listaEngenheiros.get(idxEng);
            o.setDtInicio(dao.TelaHelper.parseData(dtInicio.getText()));
            o.setDtFim(dao.TelaHelper.parseData(dtTermino.getText()));
            o.setEngenheiroResponsavel(eng);
            o.setNrCrea(eng.getNrCREA());
            o.setDtAdmissaoEngenheiro(eng.getDtAdmissao());

            new dao.ObraDAO().alterar(o);
            dao.TelaHelper.aviso(this, "Obra alterada com sucesso!");
            dao.TelaHelper.abrirTela(this, "JFObras");
        } catch (Exception ex) {
            dao.TelaHelper.erro(this, "Erro ao alterar obra (use datas dd/MM/aaaa):", ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bntSalvar = new javax.swing.JButton();
        bntCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        CBObra = new javax.swing.JComboBox<>();
        dtTermino = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CBEngenheiro = new javax.swing.JComboBox<>();
        codigo = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        dtInicio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        PaginaInicial = new javax.swing.JMenu();
        Obra = new javax.swing.JMenu();
        FaseObra = new javax.swing.JMenu();
        Engenheiro = new javax.swing.JMenu();
        Funcao = new javax.swing.JMenu();
        Orcamento = new javax.swing.JMenu();
        Sair = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Alterar Obra");

        bntSalvar.setBackground(new java.awt.Color(51, 102, 255));
        bntSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bntSalvar.setText("Salvar Fase");
        bntSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));

        bntCancelar.setBackground(new java.awt.Color(242, 242, 242));
        bntCancelar.setText("Cancelar ");
        bntCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Preencha os dados da obra para efetuar a alteração no sistema.");

        CBObra.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setText("Engenheiro Responsável Técnico");

        CBEngenheiro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel9.setText("Código");

        jLabel10.setText("Data de Início");

        jLabel5.setText("Data de Término (Prevista/Real)");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(CBObra, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(53, 53, 53))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(305, 305, 305))
                            .addComponent(CBEngenheiro, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dtTermino)
                            .addComponent(dtInicio)
                            .addComponent(codigo))
                        .addGap(55, 55, 55))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CBObra, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dtInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dtTermino, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CBEngenheiro, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bntSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jMenuBar1.setMaximumSize(new java.awt.Dimension(630, 42768));

        PaginaInicial.setText("Página Inicial");
        jMenuBar1.add(PaginaInicial);

        Obra.setText("Obras");
        jMenuBar1.add(Obra);

        FaseObra.setText("Fases da obra");
        jMenuBar1.add(FaseObra);

        Engenheiro.setText("Engenheiros");
        jMenuBar1.add(Engenheiro);

        Funcao.setText("Funções");
        jMenuBar1.add(Funcao);

        Orcamento.setText("Orçamentos");
        jMenuBar1.add(Orcamento);

        Sair.setText("Sair");
        jMenuBar1.add(Sair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bntCancelarActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFAlteraObra().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBEngenheiro;
    private javax.swing.JComboBox<String> CBObra;
    private javax.swing.JMenu Engenheiro;
    private javax.swing.JMenu FaseObra;
    private javax.swing.JMenu Funcao;
    private javax.swing.JMenu Obra;
    private javax.swing.JMenu Orcamento;
    private javax.swing.JMenu PaginaInicial;
    private javax.swing.JMenu Sair;
    private javax.swing.JButton bntCancelar;
    private javax.swing.JButton bntSalvar;
    private javax.swing.JTextField codigo;
    private javax.swing.JTextField dtInicio;
    private javax.swing.JTextField dtTermino;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
