
package model;

import java.time.LocalDate;

public class Orcamento {
    private int idOrcamento;
    private LocalDate dtAprovacao;
    private Engenheiro engenheiroResponsavel;

    public Orcamento() {}

    public Orcamento(int idOrcamento, LocalDate dtAprovacao, Engenheiro engenheiroResponsavel) {
        this.idOrcamento = idOrcamento;
        this.dtAprovacao = dtAprovacao;
        this.engenheiroResponsavel = engenheiroResponsavel;
    }

    public int getIdOrcamento() { return idOrcamento; }
    public void setIdOrcamento(int idOrcamento) { this.idOrcamento = idOrcamento; }

    public LocalDate getDtAprovacao() { return dtAprovacao; }
    public void setDtAprovacao(LocalDate dtAprovacao) { this.dtAprovacao = dtAprovacao; }

    public Engenheiro getEngenheiroResponsavel() { return engenheiroResponsavel; }
    public void setEngenheiroResponsavel(Engenheiro engenheiroResponsavel) { this.engenheiroResponsavel = engenheiroResponsavel; }
}