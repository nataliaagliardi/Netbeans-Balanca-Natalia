package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ObraOrcamento {
    private Orcamento orcamento;
    private Obra obra;
    private LocalDate dtInicio;
    private LocalDate dtFim;
    private BigDecimal vlPrevisto;
    private BigDecimal vlRealizado;

    public ObraOrcamento() {}

    public ObraOrcamento(Orcamento orcamento, Obra obra, LocalDate dtInicio, LocalDate dtFim, 
                         BigDecimal vlPrevisto, BigDecimal vlRealizado) {
        this.orcamento = orcamento;
        this.obra = obra;
        this.dtInicio = dtInicio;
        this.dtFim = dtFim;
        this.vlPrevisto = vlPrevisto;
        this.vlRealizado = vlRealizado;
    }

    public Orcamento getOrcamento() { return orcamento; }
    public void setOrcamento(Orcamento orcamento) { this.orcamento = orcamento; }

    public Obra getObra() { return obra; }
    public void setObra(Obra obra) { this.obra = obra; }

    public LocalDate getDtInicio() { return dtInicio; }
    public void setDtInicio(LocalDate dtInicio) { this.dtInicio = dtInicio; }

    public LocalDate getDtFim() { return dtFim; }
    public void setDtFim(LocalDate dtFim) { this.dtFim = dtFim; }

    public BigDecimal getVlPrevisto() { return vlPrevisto; }
    public void setVlPrevisto(BigDecimal vlPrevisto) { this.vlPrevisto = vlPrevisto; }

    public BigDecimal getVlRealizado() { return vlRealizado; }
    public void setVlRealizado(BigDecimal vlRealizado) { this.vlRealizado = vlRealizado; }
}