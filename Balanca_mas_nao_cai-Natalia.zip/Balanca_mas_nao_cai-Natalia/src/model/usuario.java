
package model;

public class usuario {
    private int idUsuario;
    private String nome;
    private String email;
    private String senha;
    private int flStatus;

    public usuario() {}

    public usuario(int idUsuario, String nome, String email, String senha, int flStatus) {
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.flStatus = flStatus;
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public int getFlStatus() { return flStatus; }
    public void setFlStatus(int flStatus) { this.flStatus = flStatus; }
}

