
package balanca_mas_nao_cai.natalia;


public class Balanca_mas_nao_caiNatalia {

    public static void main(String[] args) {
    }
    
}
